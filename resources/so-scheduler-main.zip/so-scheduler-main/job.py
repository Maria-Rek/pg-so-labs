from dataclasses import dataclass

@dataclass
class Job:
    name: str
    priority: int
    burst_time: int
    arrival_time: int
    deadline: int
