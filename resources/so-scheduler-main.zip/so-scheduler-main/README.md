# Simplified Kernel Scheduler Simulator
This Python-based kernel scheduler simulator models the core behavior of an operating system’s CPU scheduling mechanisms. Designed for educational and experimental purposes, it provides implementations of several common scheduling algorithms — including First-Come, First-Served (FCFS), Shortest Job First (SJF), Earliest Deadline First (EDF), Round Robin (RR), and Priority Scheduling. Each algorithm runs independently in a modular fashion, allowing users to compare and analyze different scheduling strategies under varied job workloads.

The simulator accepts job definitions from a CSV input file specifying job names, priorities, CPU burst times, arrival times, and deadlines. It then executes the selected scheduling algorithm based on a command-line interface, outputting detailed step-by-step execution logs, including which job is running, for how long, and resource utilization.

Additionally, it computes key performance metrics such as average waiting time, turnaround time, and response time for the scheduled jobs, helping users understand the efficiency and fairness of each scheduling technique.

## Usage

### Input File Format

The input file (e.g., jobs.txt) should be in CSV format:

```csv
job_name,priority,burst,start_time,deadline
JobA,5,10,0,-1
JobB,3,5,2,20
JobC,4,8,4,18
```
### Running the Simulation
The program accepts two command-line arguments:
1. The input file (e.g., jobs.txt)
1. The scheduler type

Valid scheduler types are:
- sjf
- edf
- fcfs
- rr
- priority

Execution:
```bash
python main.py jobs.txt sjf
python main.py jobs.txt edf
python main.py jobs.txt fcfs
python main.py jobs.txt rr
python main.py jobs.txt priority
```