def schedule(jobs):
    time = 0
    completed = []
    jobs = sorted(jobs, key=lambda j: j.arrival_time)

    for job in jobs:
        start = max(time, job.arrival_time)
        completion = start + job.burst_time
        arrival = job.arrival_time
        burst = job.burst_time

        turnaround = completion - arrival
        waiting = turnaround - burst
        response = start - arrival

        print(
            f"Running job: [{job.name}] ([Priority: {job.priority}, Burst: {job.burst_time}] for {job.burst_time} time units."
        )

        time = completion

        completed.append({
            "job": job,
            "start_time": start,
            "completion_time": completion,
            "waiting_time": waiting,
            "turnaround_time": turnaround,
            "response_time": response
        })

    return completed
