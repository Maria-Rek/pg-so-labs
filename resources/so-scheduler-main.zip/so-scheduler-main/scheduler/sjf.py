def schedule(jobs):
    time = 0
    completed_jobs = []
    jobs = sorted(jobs, key=lambda j: (j.arrival_time, j.burst_time))
    queue = []

    while jobs or queue:
        while jobs and jobs[0].arrival_time <= time:
            queue.append(jobs.pop(0))

        if queue:
            queue.sort(key=lambda j: j.burst_time)
            job = queue.pop(0)

            start = max(time, job.arrival_time)
            completion = start + job.burst_time
            arrival = job.arrival_time
            burst = job.burst_time

            turnaround = completion - arrival
            waiting = turnaround - burst
            response = start - arrival

            print(
                f"Running job: [{job.name}] ([Priority: {job.priority}, Burst: {job.burst_time}] for {job.burst_time} time units."
            )

            time = completion

            completed_jobs.append({
                "job": job,
                "start_time": start,
                "completion_time": completion,
                "waiting_time": waiting,
                "turnaround_time": turnaround,
                "response_time": response
            })
        else:
            time += 1

    return completed_jobs
