def schedule(jobs, quantum=2):
    time = 0
    queue = []
    completed = []
    jobs = sorted(jobs, key=lambda j: j.arrival_time)
    remaining = {job.name: job.burst_time for job in jobs}
    first_run = {}
    last_active = {}

    while jobs or queue:
        while jobs and jobs[0].arrival_time <= time:
            queue.append(jobs.pop(0))

        if queue:
            queue.sort(key=lambda j: (j.priority, -j.arrival_time), reverse=True)
            job = queue.pop(0)

            if job.name not in first_run:
                first_run[job.name] = time

            exec_time = min(quantum, remaining[job.name])

            print(
                f"Running job: [{job.name}] ([Priority: {job.priority}, Burst: {remaining[job.name]}] for {exec_time} time units."
            )

            time += exec_time
            remaining[job.name] -= exec_time
            last_active[job.name] = time

            while jobs and jobs[0].arrival_time <= time:
                queue.append(jobs.pop(0))

            if remaining[job.name] > 0:
                queue.append(job)
            else:
                arrival = job.arrival_time
                burst = job.burst_time
                start = first_run[job.name]
                completion = last_active[job.name]
                turnaround = completion - arrival
                waiting = turnaround - burst
                response = start - arrival

                completed.append({
                    "job": job,
                    "start_time": start,
                    "completion_time": completion,
                    "waiting_time": waiting,
                    "turnaround_time": turnaround,
                    "response_time": response
                })
        else:
            time += 1

    return completed
