import sys
import csv
from job import Job
import scheduler.sjf as sjf
import scheduler.edf as edf
import scheduler.fcfs as fcfs
import scheduler.rr as rr
import scheduler.priority as priority
import scheduler.priority_rr as priority_rr

def load_jobs_from_csv(filename):
    jobs = []
    with open(filename, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            jobs.append(Job(
                name=row['job_name'],
                priority=int(row['priority']),
                burst_time=int(row['burst']),
                arrival_time=int(row['start_time']),
                deadline=int(row['deadline'])
            ))
    return jobs


def print_metrics(job_logs):
    total_waiting = 0
    total_turnaround = 0
    total_response = 0
    n = len(job_logs)

    print("\nExecution Timeline:")
    for log in job_logs:
        waiting = log["waiting_time"]
        turnaround = log["turnaround_time"]
        response = log["response_time"]

        total_waiting += waiting
        total_turnaround += turnaround
        total_response += response

    print("\nSummary:")
    print(f"Average waiting time     = {total_waiting / n:.2f}")
    print(f"Average turnaround time  = {total_turnaround / n:.2f}")
    print(f"Average response time    = {total_response / n:.2f}")


def main():
    if len(sys.argv) != 3:
        print("Usage: python main.py <jobs_file.csv> <algorithm>")
        sys.exit(1)

    jobs_file = sys.argv[1]
    algorithm = sys.argv[2]
    jobs = load_jobs_from_csv(jobs_file)

    schedulers = {
        'sjf': sjf.schedule,
        'edf': edf.schedule,
        'fcfs': fcfs.schedule,
        'rr': rr.schedule,
        'priority': priority.schedule,
        'priority_rr': priority_rr.schedule
    }

    if algorithm not in schedulers:
        print(f"Unknown algorithm '{algorithm}'.")
        sys.exit(1)

    result = schedulers[algorithm](jobs)
    print_metrics(result)
    # for log in result:
    #     print(log)

if __name__ == '__main__':
    main()
